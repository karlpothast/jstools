

Get-NetTCPConnection -State Established


Get-NetTCPConnection -AppliedSetting Internet

Get-NetTCPConnection | Where-Object Localport -eq 5000 | Select-Object Localport,OwningProcess


Test-Connection -LocalPort 80