



# if (Test-PortOpen -Port 8080) {
#     "Port 5000 is in use."
# } else {
#     "Port 5000 is available."
# }


Test-PortOpen -Port 8080