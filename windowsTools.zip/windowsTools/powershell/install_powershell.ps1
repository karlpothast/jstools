

winget search Microsoft.PowerShell


#%SystemRoot%\system32\WindowsPowerShell\v1.0\powershell.exe -nologo