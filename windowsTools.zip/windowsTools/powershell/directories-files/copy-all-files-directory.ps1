
Copy-Item "C:\SourceDirectory\*" "C:\DestinationDirectory\" -Recurse
