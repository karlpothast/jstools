
#Invoke-WebRequest https://get.pnpm.io/install.ps1 -UseBasicParsing | Invoke-Expression


#pnpm config get prefix

npm install -g pnpm
