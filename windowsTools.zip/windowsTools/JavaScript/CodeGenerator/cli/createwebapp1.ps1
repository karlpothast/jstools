
copy_all_files C:\Users\karlp\workspaces\JavaScript\templates\css_html_js1 ./