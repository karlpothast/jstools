
let headerText = document.querySelector('.header-text');

window.onload = async function() {
 setTitle("");
};

function setTitle(pageTitle) {
  document.title = pageTitle;
  headerText.innerText = pageTitle;
}

