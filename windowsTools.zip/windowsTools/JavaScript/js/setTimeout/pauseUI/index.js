

let headerSpan = document.querySelector('.header-text');
let spanScreenMessageText = document.querySelector('#spanScreenMessageText');

window.onload = async function() {
 setTitle("Set Timeout - Pause UI");

 console.log("")
 console.log("start")
 console.log("sleep 2 seconds")
 await sleep(2);
 console.log("end")

 loadSequence();

};

function setTitle(pageTitle) {
  document.title = pageTitle;
  headerSpan.innerText = pageTitle;
}

function setMessage(msg) {
 spanScreenMessageText.innerText = msg;
}

function loadSequence() {

  //msg1
  spanScreenMessageText.style.opacity=0;

   setTimeout(() => {
    setMessage("Start of Sequence");
    $("#spanScreenMessageText")
      .css({ opacity: 0 })
      .animate({ opacity: 1 }, { duration: 1000 })
      .animate({ opacity: 0 }, { duration: 1000 })
   }, 1000);

   setTimeout(() => {
    setMessage("Middle of Sequence /n Two Seconds");
    $("#spanScreenMessageText")
      .css({ opacity: 0 })
      .animate({ opacity: 1 }, { duration: 1000 })
      .animate({ opacity: 0 }, { duration: 1000 })
   }, 3000);





  // setTimeout(() => {
  //   $("#spanScreenMessageText")
  //     .animate({ opacity: 0 }, { duration: 1000 })
  //  }, 2000);
  
  

  
  // //msg2
  // setTimeout(() => {
  //   $("#lightning1")
  //     .css({ visibility: "visible" })
  //     .css({ opacity: 1.0 })
  //     .animate({ opacity: 0.0 }, { duration: 800 });
  // }, 2000);

  // //msg3
  // setTimeout(() => {
  //   $("#lightning1")
  //     .css({ visibility: "visible" })
  //     .css({ opacity: 1.0 })
  //     .animate({ opacity: 0.0 }, { duration: 800 });
  // }, 2000);

}

async function sleep(seconds){
  var milliseconds = seconds * 1000;
  await new Promise(resolve => setTimeout(resolve, milliseconds))
}