function Prompt {
    if ( Test-Path Variable:Global:RedactPreviousLine ) { 
        $cursor = New-Object System.Management.Automation.Host.Coordinates
        $cursor.X = $host.ui.rawui.CursorPosition.X
        $cursor.Y = $host.ui.rawui.CursorPosition.Y - 1
        $host.ui.rawui.CursorPosition = $cursor
        Write-host $( " " * ( $host.ui.RawUI.WindowSize.Width - 1 ) )
        $host.ui.rawui.CursorPosition = $cursor

        Remove-Variable RedactPreviousLine -scope global
        } # end if 
    "PS $($executionContext.SessionState.Path.CurrentLocation)$('>' * ($nestedPromptLevel + 1)) ";
    # .Link
    # https://go.microsoft.com/fwlink/?LinkID=225750
    # .ExternalHelp System.Management.Automation.dll-help.xml
    } # end function prompt
