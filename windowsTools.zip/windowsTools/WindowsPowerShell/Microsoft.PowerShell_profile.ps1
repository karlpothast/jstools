$sourceFile = "$HOME\\OneDrive\Documents\\WindowsPowerShell\\source_files.ps1"
if (Test-Path $sourceFile) {
  Write-Host "Source VSCode Profile"
  . $sourceFile
} else {
  Write-Host "VSCode profile source file not found";
}
