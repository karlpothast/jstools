function Test-PortOpen {
    param([int]$Port)

    $inUse = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
    return $inUse -ne $null
}

function isPortInUse {
    param([int]$Port)

    $inUse = netstat -ano | Select-String $Port
    return $inUse -ne $null
}

function rm {
  Remove-Item -Recurse -Force -Confirm:$false
}

function touch {
  param([string]$fileName)

  New-Item -ItemType file $fileName
}

function b {
  Set-Location ..;
}

function la {
  Get-ChildItem -Path .\ -Force
}

function less {
    param (
        [Parameter(ValueFromPipeline = $true)]
        $InputObject
    )
    process {
        $InputObject | Out-Host -Paging
    }
}

function dotnet_run {
  dotnet run;
}

function copy_all_files {
  param([string]$srcDir, 
  [string]$destDir)

  Copy-Item $srcDir"\*" $destDir -Recurse
  #Copy-Item "C:\SourceDirectory\*" "C:\DestinationDirectory\" -Recurse

}

function create_web_app {
  C:\Users\karlp\workspaces\JavaScript\CodeGenerator\cli\createwebapp1.ps1;
}

