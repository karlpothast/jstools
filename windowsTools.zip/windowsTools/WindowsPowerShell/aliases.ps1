Set-Alias c Clear-Host;
Set-Alias p PowerShell;
Set-Alias l less;
Set-Alias .r dotnet_run;
Set-Alias cweb create_web_app;
Set-Alias web live-server;
