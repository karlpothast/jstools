
$env:DOTNET_ENV = "Development"
$env:API_URL = "https://localhost:5001"
$env:MY_PROJECTS = "C:\Users\YourName\Projects"

$toolsPath = "$HOME\\tools"
if (-not ($env:PATH -like "*$toolsPath*")) {
    $env:PATH = "$toolsPath;$env:PATH"
}