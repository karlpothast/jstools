$promptFile = "$HOME\\OneDrive\Documents\\WindowsPowerShell\\prompt.ps1"
if (Test-Path $promptFile) {
  . $promptFile
} else {
  Write-Host "Prompt file not found";
}

$VerbosePreference = 'SilentlyContinue';

$envFile = "$HOME\\OneDrive\Documents\\WindowsPowerShell\\env.ps1"
if (Test-Path $envFile) {
  . $envFile
} else {
  Write-Host "Env file not found";
}

$functionsFile = "$HOME\\OneDrive\Documents\\WindowsPowerShell\\functions.ps1"
if (Test-Path $functionsFile) {
  . $functionsFile
} else {
  Write-Host "Functions file not found";
}

$aliasFile = "$HOME\\OneDrive\Documents\\WindowsPowerShell\\aliases.ps1"
if (Test-Path $aliasFile) {
  . $aliasFile
} else {
  Write-Host "Aliases file not found";
}

Clear-Host;
Write-Host "PS Prompt, Env, function & alias files sourced";
sleep 1;

$global:RedactPreviousLine = $True;
Clear-Host;
