﻿$(function () {
    var MainView = Backbone.View.extend({
        el: "body",
        events: {
            "paste #dropZone": "handlePaste"
        },
        initialize: function () {
            this.$status = this.$("#status");
            this.updateStatus("Ready to paste image...");
        },
        updateStatus: function (msg) {
            this.$status.text(msg);
            this.$status[0].scrollTop = this.$status[0].scrollHeight;
        },
        handlePaste: function (e) {
            var items = (e.originalEvent || e).clipboardData.items;
            for (var i = 0; i < items.length; i++) {
                if (items[i].type.indexOf("image") !== -1) {
                    var blob = items[i].getAsFile();
                    var formData = new FormData();
                    formData.append("image", blob, "pasted.png");
                    this.updateStatus("📷 IMAGE PASTED\n⏳ RUNNING OCR...");
                    var self = this;
                    $.ajax({
                        url: "OCRHandler.ashx",
                        type: "POST",
                        data: formData,
                        processData: false,
                        contentType: false,
                        success: function (text) {
                            self.updateStatus("✅ OCR COMPLETE\n📋 COPYING TO CLIPBOARD...");
                            self.copyToClipboard(text);
                            self.updateStatus("✅ TEXT COPIED TO CLIPBOARD\n🔎 CHECKING FOR SPELLING ERRORS...");
                            self.checkSpelling(text);
                        },
                        error: function () {
                            self.updateStatus("❌ ERROR DURING OCR");
                        }
                    });
                    break;
                }
            }
        },
        copyToClipboard: function (text) {
            navigator.clipboard.writeText(text).catch(function () { });
        },
        checkSpelling: function (text) {
            var self = this;
            $.ajax({
                url: "https://api.languagetool.org/v2/check",
                method: "POST",
                data: { text: text, language: "en-US" },
                success: function (response) {
                    if (response && response.matches && response.matches.length > 0) {
                        var messages = response.matches.map(m => `• ${m.message} (${m.replacements.map(r => r.value).join(', ')})`);
                        self.updateStatus("✅ SPELLING CHECK COMPLETE\n⚠️ Suggestions:\n" + messages.join("\n"));
                    } else {
                        self.updateStatus("✅ SPELLING CHECK COMPLETE\n✅ No issues found.");
                    }
                },
                error: function () {
                    self.updateStatus("❌ ERROR DURING SPELL CHECK.");
                }
            });
        }
    });

    new MainView();
});